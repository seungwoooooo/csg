﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class AddButtons : MonoBehaviour {

    [SerializeField]
    private Transform puzzleField;
    [SerializeField]
    private GameObject btn;
    [SerializeField]
    private int numberOfMatches = 4;
    //[SerializeField]
    //private GameObject panel;

	// Use this for initialization
	void Awake () {

        for (int i = 0; i < numberOfMatches * 2; i++)
        {
            GameObject button = Instantiate(btn);
            // Name our buttons 
            button.name = "" + i;
            button.transform.SetParent(puzzleField, false);
        }

        //// Adjust grid
        //panel.GetComponent<GridLayoutGroup>().constraintCount = numberOfMatches;
	
	}
}
