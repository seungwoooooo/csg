﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;

public class GameController : MonoBehaviour {

    [SerializeField]
    private Sprite bgImage;
    [SerializeField]
    private Text gameOverText;

    public Sprite[] puzzles;

    public List<Sprite> gamePuzzles = new List<Sprite>();

    public List<Button> btns = new List<Button>();

    private bool firstGuess, secondGuess;
    private int firstGuessIndex, secondGuessIndex;
    private int countGuesses;
    private int countCorrectGuesses;
    private int gameGuesses;

    void Awake()
    {
        // initialize puzzle pieces
        puzzles = Resources.LoadAll<Sprite>("Sprites/platinum-back");
    }

	// Use this for initialization
	void Start () {

        GetButtons();
        AddListeners();
        AddGamePuzzles();
        Shuffle(gamePuzzles);
        gameGuesses = gamePuzzles.Count / 2;
	
	}
	
	void GetButtons () {
        GameObject[] objects = GameObject.FindGameObjectsWithTag("PuzzleButton");

        for(int i = 0; i < objects.Length; i++)
        {
            // Add the PuzzleButton to btns list
            btns.Add(objects[i].GetComponent<Button>());
            // Assign a background image
            btns[i].image.sprite = bgImage;
        }
	}

    void AddGamePuzzles()
    {
        for (int i = 0; i < btns.Count / 2; i++)
        {
            gamePuzzles.Add(puzzles[i]);
            gamePuzzles.Add(puzzles[i]);
        }
    }

    void AddListeners()
    {
        // add puzzle pieces for each button
        foreach (Button btn in btns)
        {
            btn.onClick.AddListener(() => PickAPuzzle());
        }
    }

    public void PickAPuzzle ()
    {
        string name = UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject.name;

        if (!firstGuess)
        {
            firstGuessIndex = int.Parse(name);
            
            btns[firstGuessIndex].image.sprite = gamePuzzles[firstGuessIndex];

            firstGuess = true;
        }
        else if (!secondGuess)
        {
            secondGuessIndex = int.Parse(name);

            if (firstGuessIndex == secondGuessIndex)
            {
                return;
            }

            btns[secondGuessIndex].image.sprite = gamePuzzles[secondGuessIndex];
            
            secondGuess = true;

            countGuesses++;

            StartCoroutine(CheckIfThePuzzlesMatch());
        }
    }

    IEnumerator CheckIfThePuzzlesMatch()
    {
        yield return new WaitForSeconds(1f);

        // first piece matches second
        if (btns[firstGuessIndex].image.sprite.name == btns[secondGuessIndex].image.sprite.name)
        {
            btns[firstGuessIndex].interactable = false;
            btns[secondGuessIndex].interactable = false;

            btns[firstGuessIndex].image.color = new Color(0, 0, 0, 0.2f);
            btns[secondGuessIndex].image.color = new Color(0, 0, 0, 0.2f);

            CheckIfTheGameIsFinished();
        }
        else
        {
            btns[firstGuessIndex].image.sprite = bgImage;
            btns[secondGuessIndex].image.sprite = bgImage;
        }

        firstGuess = secondGuess = false;
    }

    void CheckIfTheGameIsFinished()
    {
        countCorrectGuesses++;

        if (countCorrectGuesses == gameGuesses)
        {
            gameOverText.text = "Game!\nYou finished in " + countGuesses + " guesses.";

            if (countGuesses == 1)
            {
                gameOverText.text += "\nOops, I mean 1 guess.\nMaybe try matching more than one pair this time.";
            }
            else if (countGuesses <= gameGuesses * 1.3f)
            {
                gameOverText.text += "\nIncredible!";
            }
            else if (countGuesses <= gameGuesses * 1.7f)
            {
                gameOverText.text += "\nNice!";
            }
            else if (countGuesses <= gameGuesses * 2.0f)
            {
                gameOverText.text += "\nYou need practice.";
            }
            else
            {
                gameOverText.text += "\nYou are really, really bad.";
            }

            gameOverText.enabled = true;
        }
    }

    void Shuffle(List<Sprite> list)
    {
        for (int i = 0; i < list.Count; i++)
        {
            Sprite temp = list[i];
            int randomIndex = Random.Range(0, list.Count);
            list[i] = list[randomIndex];
            list[randomIndex] = temp;
        }
    }
}
